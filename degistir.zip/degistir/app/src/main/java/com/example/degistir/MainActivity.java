package com.example.degistir;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.renderscript.ScriptGroup;
import android.view.View;

import com.example.degistir.databinding.ActivityMainBinding;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ActivityMainBinding Binding;

    ArrayList<Gorsel> gorselArrayList;
    int seciliSiraNo;

    public void geriGelme(View view){
        if(seciliSiraNo>0){
            seciliSiraNo--;
            Binding.imageViewGorsel.setImageResource(gorselArrayList.get(seciliSiraNo).foto);
            Binding.textViewBilgi.setText("Bilgi : " + gorselArrayList.get(seciliSiraNo).bilgi);
        }
    }

    public void ileriGitme(View view){
        if(seciliSiraNo<gorselArrayList.size()-1){
            seciliSiraNo++;
            Binding.imageViewGorsel.setImageResource(gorselArrayList.get(seciliSiraNo).foto);
            Binding.textViewBilgi.setText("Bilgi : " + gorselArrayList.get(seciliSiraNo).bilgi);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = Binding.getRoot();
        setContentView(view);

        Gorsel a = new Gorsel("fotograf 1",1,R.drawable.a);
        Gorsel b = new Gorsel("fotograf 2",2,R.drawable.b);
        Gorsel c = new Gorsel("fotograf 3",3,R.drawable.c);
        Gorsel d = new Gorsel("fotograf 4",4,R.drawable.d);

        gorselArrayList = new ArrayList<>();

        gorselArrayList.add(a);
        gorselArrayList.add(b);
        gorselArrayList.add(c);
        gorselArrayList.add(d);

        Binding.imageViewGorsel.setImageResource(gorselArrayList.get(0).foto);
        Binding.textViewBilgi.setText("Bilgi : " + gorselArrayList.get(0).bilgi);

        seciliSiraNo=0;
    }
}